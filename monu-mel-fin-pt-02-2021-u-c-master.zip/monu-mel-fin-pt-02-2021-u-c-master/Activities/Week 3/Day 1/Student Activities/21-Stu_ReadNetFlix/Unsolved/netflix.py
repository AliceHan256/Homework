# Modules
import os
import csv

# Prompt user for video lookup


# Set path for CSV file


# Open the file and loop through to search for the video
# If video is found, print title, rating, and user ratings. 
# If the video is never found, alert the user
