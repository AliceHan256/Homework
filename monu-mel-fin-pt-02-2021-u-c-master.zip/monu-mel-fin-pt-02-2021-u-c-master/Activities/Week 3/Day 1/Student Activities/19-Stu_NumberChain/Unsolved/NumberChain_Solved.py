# Initial variable to track game play

# While we are still playing...

    # Ask the user how many numbers to loop through

    # Loop through the numbers. (Be sure to cast the string into an integer.)

        # Print each number in the range

    # Once complete, as the user if they would like to continue
