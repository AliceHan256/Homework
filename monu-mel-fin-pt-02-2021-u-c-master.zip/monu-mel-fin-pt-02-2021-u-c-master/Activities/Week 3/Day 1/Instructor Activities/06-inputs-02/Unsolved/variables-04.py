# Declare a variable of `name` with an input and a string of "Welcome to the Boba Shop! What is your name?".


# Check if `name` is not an empty string or equal to `None`.

    # If so, write a print statement with a string of "Hello" concatenated with the variable `name`.


    # Then, declare a variable of `beverage` with an input and a string of "What kind of boba drink would you like?".


    # Then, Declare a variable of `sweetness_level` with an input and a string of "How sweet do you want your drink: 0, 50, 100, or 200?".


    # If `sweetness` equals 50 print "half sweetened".

    # Else if `sweetness` 100 print "normal sweet".

    # Else if `sweetness` 200 print "super sweet".

    # Else print with a string of "non-sweet".


    # Then print the string of "Your order of " concatenated with the variable `beverage`, concatenated with " boba with a sweet level of ", concatenated with the variable `sweetness`

# Else, print the string of "You didn't give us your name! Goodbye"


