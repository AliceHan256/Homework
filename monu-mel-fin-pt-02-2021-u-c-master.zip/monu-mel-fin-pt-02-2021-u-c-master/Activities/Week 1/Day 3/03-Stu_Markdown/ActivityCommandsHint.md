# Examples of markdown 

## Bold
This is a bold **word**
## Italics
This is an italics *word*

# Activity instructions
Add a level 1 header to the `README` title.
# Heading level 1
---
Add an image. (It doesn't need to be FinTech-related.)
![](image.png)
---
Add a level 2 header for the `README` description.
## Heading level 2
---
Add a level 3 header for the `README` table of contents.
### Heading level 3
---
Add links to each subfolder within the table of contents.
example : Here is a link [link text](https://www.bootcampspot.com)
---
