# -*- coding: utf-8 -*-
"""
Student Do: Grocery List.

This script showcases basic operations of Python Lists to help Mike
organize his grocery shopping list.
"""

# @TODO: Create a list of groceries





# @TODO: Find the first two items on the list




# @TODO: Find the last five items on the list




# @TODO: Find every other item on the list, starting from the second item




# @TODO: Add an element to the end of the list





# @TODO: Changes a specified element within the list at the given index





# @TODO: Calculate how many items you have in the list


