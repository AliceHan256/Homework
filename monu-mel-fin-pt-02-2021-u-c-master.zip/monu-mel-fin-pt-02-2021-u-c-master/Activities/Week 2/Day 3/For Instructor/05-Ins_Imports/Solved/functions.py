def print_hello():
    print("hello!")

def print_goodbye():
    print("goodbye!")