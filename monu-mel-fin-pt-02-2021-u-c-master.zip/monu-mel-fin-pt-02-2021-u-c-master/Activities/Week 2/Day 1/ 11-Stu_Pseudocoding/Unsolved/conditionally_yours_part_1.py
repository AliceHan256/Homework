"""
Conditionally Yours

Pseudocode:


"""
