"""
Conditionally Yours

Pseudocode:


"""

# Increase = Current Price - Original Price
# Percent Increase = Increase / Original x 100

# Create integer variable for original_price


# Create integer variable for current_price


# Create float for threshold_to_buy


# Create float for threshold_to_sell


# Create float for portfolio balance


# Create float for balance check


# Create string for recommendation, default will be buy
recommendation = "buy"

# Calculate difference between current_price and original_price


# Calculate percent increase


# Print original_price
print(f"Netflix's original stock price was ${original_price}")

# Print current_price


# Print percent increase


# Determine if stock should be bought or sold


# Print recommendation
print("Recommendation: " + recommendation)
print()
