# MONU-MEL-FIN-PT-02-2021-U-C

## <center>Week 1</center>
 <table>
  <tr>
    <th></th>
    <th>Slides</th>
    <th>Activities</th>
    <th>Homework</th>
  </tr>
  <tr>
    <td rowspan="2">Day 1</td>
  </tr>
  <tr>
    <td><a href="https://monash.bootcampcontent.com/monash-coding-bootcamp/monu-mel-fin-pt-02-2021-u-c/-/blob/master/Lesson%20Slides/Week%201/fintech-01-1-welcome-to-fintech-v1.0.0.pdf">fintech-01-1-welcome-to-fintech</a></td>
    <td>
        <ul>
            <li><a href="https://monash.bootcampcontent.com/monash-coding-bootcamp/monu-mel-fin-pt-02-2021-u-c/-/tree/master/Activities/Week%201/Day%201">Week 1 Day 1</a></li>
        </ul>
    </td>
    <td rowspan="5">
        <ul>
            <li><a href="https://monash.bootcampcontent.com/monash-coding-bootcamp/monu-mel-fin-pt-02-2021-u-c/blob/master/Homework/Week%201/README.md">Unit 1 Homework Assignment: FinTech Case Study</a></li>
            <li><strong>Due Date: Thursday, February 18</li>
        </ul>
    </td>
  </tr>
  <tr>
    <td rowspan="2">Day 2</td>
  </tr>
  <tr>
    <td><a href="https://monash.bootcampcontent.com/monash-coding-bootcamp/monu-mel-fin-pt-02-2021-u-c/blob/master/Lesson%20Slides/Week%201/fintech-01-2-deep-dive-into-fintech.pdf">fintech-01-2-deep-dive-into-fintech</a></td>
    <td>
        <ul>
            <li><a href="https://monash.bootcampcontent.com/monash-coding-bootcamp/monu-mel-fin-pt-02-2021-u-c/-/tree/master/Activities/Week%201/Day%202">week 1 Day 2</a></li>
        </ul>
    </td>

  </tr>
  <tr>
    <td rowspan="2">Day 3</td>

  </tr>
  <tr>
    <td><a href="https://monash.bootcampcontent.com/monash-coding-bootcamp/monu-mel-fin-pt-02-2021-u-c/-/blob/master/Lesson%20Slides/Week%201/CA_FinTech-01-3-Fintech-collaboration-v1.0.1.pdf">fintech-01-3-fintech-collaboration</a></td>
    <td>
        <ul>
            <li><a href="https://monash.bootcampcontent.com/monash-coding-bootcamp/monu-mel-fin-pt-02-2021-u-c/-/tree/master/Activities/Week%201/Day%203">Week 1 Day 3</a></li>    
        </ul>
    </td>
  </tr>
</table> 
<p>
  <a href="https://monash.bootcampcontent.com/monash-coding-bootcamp/monu-mel-fin-pt-02-2021-u-c/-/tree/master/Supplementary%20Material/Week%201"><strong>Supplementary Week 1 Material</strong></a> 
</p>

****
## <center>Week 2</center>
 <table>
  <tr>
    <th></th>
    <th>Slides</th>
    <th>Activities</th>
    <th>Homework</th>
  </tr>
  <tr>
    <td rowspan="2">Day 1</td>
  </tr>
  <tr>
    <td><a href="https://monash.bootcampcontent.com/monash-coding-bootcamp/monu-mel-fin-pt-02-2021-u-c/-/blob/master/Lesson%20Slides/Week%202/fintech-02-1-the-emergence-of-python-v1.0.0.pdf">fintech-02-1-the-emergence-of-python</a></td>
    <td>
        <ul>
            <li><a href="https://monash.bootcampcontent.com/monash-coding-bootcamp/monu-mel-fin-pt-02-2021-u-c/-/tree/master/Activities/Week%202/Day%201">Week 2 Day 1</a></li>
        </ul>
    </td>
    <td rowspan="5">
        <ul>
            <li><a href="https://monash.bootcampcontent.com/monash-coding-bootcamp/monu-mel-fin-pt-02-2021-u-c/-/tree/master/Homework/Week%202">Unit 2 | Homework Assignment:<br>Automate Your Day Job with Python</a></li>
            <li><strong>Due Date: Thursday, February 25</li>
        </ul>
    </td>
  </tr>
  <tr>
    <td rowspan="2">Day 2</td>
  </tr>
  <tr>
    <td><a href="https://monash.bootcampcontent.com/monash-coding-bootcamp/monu-mel-fin-pt-02-2021-u-c/-/blob/master/Lesson%20Slides/Week%202/fintech-02-2-python.pdf">fintech-02-2-python</a></td>
    <td>
        <ul>
            <li><a href="https://monash.bootcampcontent.com/monash-coding-bootcamp/monu-mel-fin-pt-02-2021-u-c/-/tree/master/Activities/Week%202/Day%202">Week 2 Day 2</a></li>
        </ul>
    </td>

  </tr>
  <tr>
    <td rowspan="2">Day 3</td>

  </tr>
  <tr>
    <td><a href="https://monash.bootcampcontent.com/monash-coding-bootcamp/monu-mel-fin-pt-02-2021-u-c/-/blob/master/Lesson%20Slides/Week%202/fintech-02-3-python.pdf">fintech-02-3-python</a></td>
    <td>
        <ul>
            <li><a href="https://monash.bootcampcontent.com/monash-coding-bootcamp/monu-mel-fin-pt-02-2021-u-c/-/tree/master/Activities/Week%202/Day%203">Week 2 Day 3</a></li>
        </ul>
    </td>
  </tr>
</table> 

<p>
  <a href="https://monash.bootcampcontent.com/monash-coding-bootcamp/monu-mel-fin-pt-02-2021-u-c/-/tree/master/Supplementary%20Material/Week%202"><strong>Supplementary Week 2 Material</strong></a> 
</p>

**** 