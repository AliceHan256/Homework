<h1>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp  Windows Keyboard Shortcuts</h1>     

  

| Shortcut                    | Action                        |
|:---------------------------:|:-----------------------------:|
| `Ctrl + C  `                | Copy                          |
|` Ctrl + X   `               | Cut                           |
|` Ctrl + V    `              | Paste                         |
| `Ctrl + A  `                | Select all                    |
|` Ctrl + Z `                 | Undo                          |
| `Ctrl + Y `                 | Redo                          |
|` Ctrl + /`                  | Comment out a line            |
| `Shift + Tab `              | Indent a line backwards       |
| `Ctrl + D  `                | Delete (moves to Recycle Bin) |
| `Ctrl + Esc`                | Opens Start Menu.             |
| `Alt + Tab   `              | Switch between open apps      |
| `Alt + Left arrow key `     | Go back                       |
| `Alt + Right arrow key  `   | Go forward                    |
|` Alt + Page Up `            | Move up one screen            |
| `Alt + Page down `          | Move down one screen          |
| `Ctrl + Alt +Tab `          | View open apps                |
|` Windows Button + Left or Right arrow key `| Manipulate split screen      