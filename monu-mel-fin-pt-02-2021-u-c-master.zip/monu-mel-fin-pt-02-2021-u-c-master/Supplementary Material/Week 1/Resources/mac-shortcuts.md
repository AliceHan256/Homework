<h1>&nbsp  Mac Keyboard Shortcuts</h1>     

  

| Shortcut                    | Action                        |
|:---------------------------:|:-----------------------------:|
| `Command-C  `               | Copy                          |
|` Command-X  `               | Cut                           |
|` Command-V   `              | Paste                         |
| `Command-A  `               | Select all                    |
|` Command-Z `                | Undo                          |
| `Shift-Command-Z`           | Redo                          |
|  `Command-S`                | Save the current document     |
|` Command + /`               | Comment out a line            |
| `Command-Delete`            | Delete (moves to Trash)       |
| `Command-Tab `              | Switch to last used app       |
